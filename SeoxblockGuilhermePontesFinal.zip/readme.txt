=== Seoxblock Twitch Blocks ===
Contributors:      Seoxblock
Tags:              block
License:           GPL-3.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-3.0.html

Seoxblock Twitch blocks.

== Description ==

Crie um plugin de embed para alguma rede social de sua escolha (como Instagram, Twitch e etc), que não tenha um bloco na base do Gutemberg.

== Changelog ==

= 0.0.1 =
* Teste WP blocks